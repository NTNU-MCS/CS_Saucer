function []=DrawList2Set2(InfMAP,Optimal_path,resolution,MID,eta)
close all
load Valls
close all
[Height Width]=size(InfMAP);
eta=Optimal_path(end-8,:)
eta(1)=eta(1)
eta(2)=eta(2)-5
MID=Height*resolution/2;
InfMAP(InfMAP==2)=64;
InfMAP(InfMAP==1)=2;


%InfMAP(InfMAP==0)=1;



legend('Closed during A* algorithm','Innitially Closed','Open List','Chosen Path',' Chosen Path')




Z=size(Optimal_path,1)
    [Avstand NearestPointPos]=min((sum((abs(Optimal_path-repmat(eta,Z,1))).^2')));

for i=1:size(Optimal_path,1)
    InfMAP(Optimal_path(i,1),Optimal_path(i,2))=3;
end
InfMAP(Optimal_path(NearestPointPos,1),Optimal_path(NearestPointPos,2))=11;

for i=1:3
InfMAP(Optimal_path(NearestPointPos-i,1),Optimal_path(NearestPointPos-i,2))=10;
end
    h4=imagesc(InfMAP);
    %colormap(flipud(gray));
    colordata2=colormap

     for i=1:8
     colordata2(i,:) =[1 0 0];
     end
          colordata2(4,:) =[0.7 0.7 0.7];
                    colordata2(3,:) =[0.5 0.5 0.5];
    colordata2(11,:)=[0.5 0.5 0]
        colordata2(12,:)=[1 0 0]

     colordata2(1,:) =[1 1 1];

    colordata2(end,:)=[0 0 0];

colormap(colordata2);
hold on    
plot(-1,-1,'square','color','k','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k')

plot(-2,-2,'square','color',[1 0 0],'MarkerSize',10,'MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0])
plot(-1,-1,'square','color',[0.5 0.5 0],'MarkerSize',10,'MarkerEdgeColor',[0.5 0.5 0],'MarkerFaceColor',[0.5 0.5 0])

plot(-1,-1,'square','color',[0.5 0.5 0.5],'MarkerSize',10,'MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5])
plot(-1,-1,'square','color',[0.7 0.7 0.7],'MarkerSize',10,'MarkerEdgeColor',[0.7 0.7 0.7],'MarkerFaceColor',[0.7 0.7 0.7])
 
h1=plot(eta(2),eta(1),'o','color','r','MarkerSize',10);
   save asss
    plot(Optimal_path(NearestPointPos-3,2),Optimal_path(NearestPointPos-3,1),'x','color','b','MarkerSize',10);

plot(-3,-3,'square','color',[0.3 0.3 0.3],'MarkerSize',10,'MarkerEdgeColor',[0.3 0.3 0.3],'MarkerFaceColor',[0.3 0.3 0.3])
plot(-3,-3,'square','color',[0 0 0],'MarkerSize',10,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[1 1 1])

legend('Scanned cell:Occupied','Closest gridcell in path','Iteration to setpoint','Scanned cell: Free','Path to follow','Vessel position','Chosen setpoint')


    hold on
    axis equal
    h2=plot(nan,nan,'--');
    h6=plot(nan,nan,'o','color','r');
    h7= plot(nan,nan,'k');
    h8=plot(nan,nan,'o','color','k')
    h9=plot(nan,nan,'o','color','r')

%Rescaling axis
    set(gca,'XTick',[0:Height/32:Height]);
    set(gca,'YTick',[0:Height/32:Height]);
    set(gca,'XtickLabels',[-MID:Height/32*resolution:MID]);
    set(gca,'YtickLabels',[MID:-Height/32*resolution:-MID]);


ROBOMAP=InfMAP
u=Optimal_pathOut1D;

eta(1)=TEST.X
eta(2)=TEST.Y
%save('EtaTolistSTUFF')
y=[0 0];
Z=length(u);
Avstand=0;

eta=eta(1:2);
%#codegen
%save('TESTlist2Eta')
Values=[u(1:Z/2) u(Z/2+1:end)];
eta=eta(2:-1:1);
%eta=[ -5.7000    0.7000]
%ETAPLOT
NearestPointPos=4;
AvstandSaved=1000;
%for i=1:64
%AvstandDummy=(eta(1)-Values(i,1))^2+(eta(2)-Values(i,2))^2;
% if AvstandDummy<AvstandSaved
%     AvstandDummy=AvstandSaved;
% NearestPointPos=i;
% end
%end

    [Avstand NearestPointPos]=min((sum((abs(Values-repmat(eta,Z/2,1))).^2')));
if (NearestPointPos-3)>1
    SetPoint=NearestPointPos-3

else SetPoint=1;
    
end

%SetPoint=max([1 NearestPointPos-3]);
y(1)=Values(SetPoint,2);
y(2)=Values(SetPoint,1);
XETA=eta(1)/resolution+MID/resolution
YETA=-eta(2)/resolution+MID/resolution
for i=1:size(Optimal_path,1)
    XVAL=Values(i,2)/resolution+MID/resolution;
        YVAL=Values(i,1)/resolution+MID/resolution;
%ROBOMAP(YVAL,XVAL)=5;
ROBOMAP(Optimal_path(i,1),Optimal_path(i,2))=10;
%etaset = u;11
end

for i=0:3
    XVAL=Values(SetPoint+i,2)/resolution+MID/resolution
        YVAL=Values(SetPoint+i,1)/resolution+MID/resolution
ROBOMAP(YVAL,XVAL)=10;
ROBOMAP(Optimal_path(SetPoint+i,1),Optimal_path(SetPoint+i,2))=20;
%etaset = u;11
end
h4=imagesc(ROBOMAP);

colormap(flipud(gray));
hold on
plot(XETA,Height-YETA,'color','b','marker','*')
h1=plot(nan,nan,'*','color','r')
set(h1,'XData',((eta(2)+MID)/resolution),'YData',Height-((-eta(1)+ MID)/resolution));


set(gca,'XTick',[0:Height/8:Height]);
set(gca,'YTick',[0:Height/8:Height]);
set(gca,'XtickLabels',[-MID:Height/8*resolution:MID]);
set(gca,'YtickLabels',[MID:-Height/8*resolution:-MID]);
