function []=DrawList2Set2(InfMAP,Optimal_path,resolution,MID,eta)


DrawList2Set2(InfMAP,Optimal_path,resolution,MID,eta)
ROBOMAP=ROBOMAP3
u=Optimal_pathOut1D;

eta(1)=TEST.X
eta(2)=TEST.Y
%save('EtaTolistSTUFF')
y=[0 0];
Z=length(u);
Avstand=0;

eta=eta(1:2);
%#codegen
%save('TESTlist2Eta')
Values=[u(1:Z/2) u(Z/2+1:end)];
eta=eta(2:-1:1);
%eta=[ -5.7000    0.7000]
%ETAPLOT
NearestPointPos=4;
AvstandSaved=1000;
%for i=1:64
%AvstandDummy=(eta(1)-Values(i,1))^2+(eta(2)-Values(i,2))^2;
% if AvstandDummy<AvstandSaved
%     AvstandDummy=AvstandSaved;
% NearestPointPos=i;
% end
%end

    [Avstand NearestPointPos]=min((sum((abs(Values-repmat(eta,Z/2,1))).^2')));
if (NearestPointPos-3)>1
    SetPoint=NearestPointPos-3

else SetPoint=1;
    
end

%SetPoint=max([1 NearestPointPos-3]);
y(1)=Values(SetPoint,2);
y(2)=Values(SetPoint,1);
XETA=eta(1)/resolution+MID/resolution
YETA=-eta(2)/resolution+MID/resolution
for i=1:size(Optimal_path,1)
    XVAL=Values(i,2)/resolution+MID/resolution;
        YVAL=Values(i,1)/resolution+MID/resolution;
%ROBOMAP(YVAL,XVAL)=5;
ROBOMAP(Optimal_path(i,1),Optimal_path(i,2))=10;
%etaset = u;11
end

for i=0:3
    XVAL=Values(SetPoint+i,2)/resolution+MID/resolution
        YVAL=Values(SetPoint+i,1)/resolution+MID/resolution
ROBOMAP(YVAL,XVAL)=10;
ROBOMAP(Optimal_path(SetPoint+i,1),Optimal_path(SetPoint+i,2))=20;
%etaset = u;11
end
h4=imagesc(ROBOMAP);

colormap(flipud(gray));
hold on
plot(XETA,Height-YETA,'color','b','marker','*')
h1=plot(nan,nan,'*','color','r')
set(h1,'XData',((eta(2)+MID)/resolution),'YData',Height-((-eta(1)+ MID)/resolution));


set(gca,'XTick',[0:Height/8:Height]);
set(gca,'YTick',[0:Height/8:Height]);
set(gca,'XtickLabels',[-MID:Height/8*resolution:MID]);
set(gca,'YtickLabels',[MID:-Height/8*resolution:-MID]);
