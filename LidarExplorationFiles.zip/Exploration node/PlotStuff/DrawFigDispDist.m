close all
MAP=ones(4)
%imagesc(MAP);
plot([0.5],0.5,'o','color','k','MarkerFaceColor','k')
hold on
plot([3.5],2.5,'o','color','k','MarkerFaceColor','k')
set(gca,'ytick',[1:4])
set(gca,'xtick',[1:4])

plot([0.5 3.5],[0.5 2.5],'color','y','LineWidth',2)
grid on
axis equal
xlim([0 4])
ylim([0 4])
load CROSS
for k=2:size(CrossSet,1)
    if mod(k,2)==0
    plot([CrossSet(k-1,1) CrossSet(k,1)]-0.05*2,[CrossSet(k-1,2) CrossSet(k,2)]+0.05*3,'k')
    %    plot([CrossSet(k-1,1) CrossSet(k-1,1)]-0.05*2,[CrossSet(k-1,2) CrossSet(k,2)]+0.05*3,'k')
    
    plot([CrossSet(k-1,1) CrossSet(k-1,1)-0.05*2]-0.027*2,[CrossSet(k-1,2) CrossSet(k-1,2)+0.05*3]+0.027*3,'k')
    plot([CrossSet(k,1) CrossSet(k,1)-0.05*2]-0.027*2,[CrossSet(k,2) CrossSet(k,2)+0.05*3]+0.027*3,'k')

    else 
            plot([CrossSet(k-1,1) CrossSet(k,1)]+0.05*2,[CrossSet(k-1,2) CrossSet(k,2)]-0.05*3,'k')
        plot([CrossSet(k-1,1) CrossSet(k-1,1)+0.05*2]+0.027*2,[CrossSet(k-1,2) CrossSet(k-1,2)-0.05*3]-0.027*3,'k')
    plot([CrossSet(k,1) CrossSet(k,1)+0.05*2]+0.027*2,[CrossSet(k,2) CrossSet(k,2)-0.05*3]-0.027*3,'k')

    end
    end
