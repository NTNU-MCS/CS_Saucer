close all
plot(InnReference.time,InnReference.Data(:,1),'k','LineWidth',2)
hold on
plot(InnReference.time,InnReference.Data(:,2),'color',[0.5 0.5 0.5],'LineWidth',2)

plot(Reference.time,Reference.Data(:,1),'--','color','k','LineWidth',2)
hold on
plot(Reference.time,Reference.Data(:,2),'--','color',[0.5 0.5 0.5],'LineWidth',2)

plot(InnReference.time,InnReference.Data(:,3),'color',[1 0 0],'LineWidth',2)
hold on
plot(Reference.time,Reference.Data(:,3),'--','color',[1 0 0],'LineWidth',2)
xlabel('Time [s]')
ylabel('Position [m], Angular Position [rad]')
legend('Desired Position, X','Reference Position, X','Desired Position, Y','Reference Position, Y','Desired Heading','Reference Heading')