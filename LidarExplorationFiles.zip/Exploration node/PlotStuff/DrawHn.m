load OpenNClosed
load HEre
close all
axis off
Hn(InfMAP==2)=max(max(Hn))+1
Hn(InfMAP==0)=-2
Hn=Hn*resolution
imagesc(Hn)
%imagesc(WeightMap)
colordata=colormap
colordata(1,:)=[1 1 1];
colordata(end,:)=[0 0 0];

colormap(colordata)
%   axis equal
%xlim([27 238])
%ylim([75 180])
%axis off
c=colorbar
c.Label.String = 'Heuristic value'; 
%c.Label.String = 'Weight of passing node'; 

hold on

%h2=plot(10,5,'o','color','g','MarkerFaceColor','g')
%h1=plot(nan,nan,'*','color','r','MarkerSize',5,'LineWidth',2);
%set(h1,'XData',RobotPositionX,'YData',RobotPositionYMap)
%legend('Vessel Position')
%plot(Optimal_path(1,2),Optimal_path(1,1),'o','color','k','MarkerFaceColor','r')
%legend('Goal')