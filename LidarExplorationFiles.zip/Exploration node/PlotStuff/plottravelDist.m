%plottravelDist
close all
clear
load HEre
 %load PreMapper
 %load HERE
%imagesc(TravelDist)
TravelDist(TravelDist==51)=2;
TravelDist(InfMAP==2)=max(max(TravelDist))+2;

TravelDist(TravelDist==0)=max(max(TravelDist));
imagesc(TravelDist)
%colormap(flipud(gray));
 colordata = colormap;
colormap(colordata);
colordata(end,:) =[0 0 0];
colordata(1,:) = [1 1 1];
imagesc(TravelDist)

hold on
colormap(colordata);
colordata = colormap;
c=colorbar
K=size(Optimal_path,1);

c.Label.String = 'Weight of node'; 
h6=plot(nan,nan,'o','color','r','LineWidth',2);%
a=als
close all
    h4=imagesc(MAP);
    colormap(flipud(gray));
RobotPositionX=80
RobotPositionYMap=110
set(h4,'CData',double(InfMAP)./2)
hold on
    h7= plot(nan,nan,'color','k','LineWidth',2);
    h8= plot(nan,nan,'o','color','b','MarkerFaceColor','b');
    set(h8,'XData',[Optimal_path(1:K,2);RobotPositionX],'YData',[Optimal_path(1:K,1);RobotPositionYMap])

    h1=plot(nan,nan,'*','color','r','MarkerSize',10);
set(h1,'XData',RobotPositionX,'YData',RobotPositionYMap)

set(h7,'XData',[Optimal_path(1:K,2);RobotPositionX],'YData',[Optimal_path(1:K,1);RobotPositionYMap])
%set(h6,'XData',Optimal_path(1,2),'YData',Optimal_path(1,1))
axis off 
axis equal
xlim([25 110])
ylim([50 150])
%Show that figure + figure of chosen close all
%TravelDist(TravelDist==0)=k*1.01;
 set(gca,'XTick',[0:Height/8:Height]);
    set(gca,'YTick',[0:Height/8:Height]);
    set(gca,'XtickLabels',[-MID:Height/8*resolution:MID]);
    set(gca,'YtickLabels',[MID:-Height/8*resolution:-MID]);
    legend('Robot Position','Planned Path','Scanner Range','Goal')
    set(h4,'ButtonDownFcn',@ImageClickCallback);
hold on
    %colormap(flipud(gray));
%colordata(end,:) = [1 1 1];
h6=plot(nan,nan,'o','color','r');
h7= plot(nan,nan,'k');

set(h6,'XData',Optimal_path(1,2),'YData',Optimal_path(1,1))
K=size(Optimal_path,1);
set(h7,'XData',[Optimal_path(1:K,2);RobotPositionX],'YData',[Optimal_path(1:K,1);RobotPositionYMap])



%plottravelDist
close all
clear
load HERE
load End Optimal_path
 load PreMapper
 load HERE
%imagesc(TravelDist)
TravelDist(TravelDist==51)=2
TravelDist(InfMAP==2)=max(max(TravelDist))+2

TravelDist(TravelDist==0)=max(max(TravelDist))
imagesc(TravelDist)

%colormap(flipud(gray));
 colordata = colormap;
colormap(colordata);
colordata(end,:) =[0 0 0];
colordata(1,:) = [1 1 1];
imagesc(TravelDist)

hold on
colormap(colordata);
colordata = colormap;
c=colorbar
K=size(Optimal_path,1);

c.Label.String = 'Weight of cell'; 
%h6=plot(nan,nan,'o','color','r','LineWidth',2);%
load 
load OptiOpti10Dist1
hold on
%plot(Optimal_path(:,2),Optimal_path(:,1),'r','LineWidth',1.5)
load OptiOpti10Dist2

%plot(Optimal_path(:,2),Optimal_path(:,1),'g','LineWidth',1.5)
load OptiOpti4Dist1 
plot(Optimal_path(:,2),Optimal_path(:,1),'r','LineWidth',1.5)
load OptiOpti4Dist2 
plot(Optimal_path(:,2),Optimal_path(:,1),'g','LineWidth',1.5)
load OptiOpti10Dist0
%plot(Optimal_path(:,2),Optimal_path(:,1),'y','LineWidth',1.5)
load OptiOpti4Dist0
plot(Optimal_path(:,2),Optimal_path(:,1),'y','LineWidth',1.5)


set(gca,'XTickLabel','')
set(gca,'YTickLabel','')
h6=plot(nan,nan,'o','color','r');
     h1=plot(nan,nan,'*','color','r','MarkerSize',5,'LineWidth',2);
set(h1,'XData',Optimal_path(end,2),'YData',Optimal_path(end,1))

set(h6,'XData',Optimal_path(1,2),'YData',Optimal_path(1,1))
K=size(Optimal_path,1);
%legend('Path: connection distance = 1','Path: connection distance = 4','Path: connection distance = 10','Goal','Vessel Position')
legend('Weighting only connection cells','Weighting all passed cells','No weigthing of cells')

axis equal
xlim([120 180])
ylim([100 150])