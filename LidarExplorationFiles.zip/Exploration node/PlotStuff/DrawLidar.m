
function ROBOMAP=DrawLidar(RobotPositionX,RobotPositionY,RefMap,ROBOMAP,resolut)
%MAP=RefMap
close all
load('Stuff')
figure(1)
RobotPositionX=RobotPositionX+5
plot(RobotPositionY,257-RobotPositionX,'*','MarkerSize',10,'color','r')
resolut=0.2
hold on
ROBOMAP=MAP

%ROBOMAP(RobotPositionX,RobotPositionY)=1;
for Degangle=0:5:360
    Radangle=Degangle*pi/180;
for r=0:0.5:10/resolut;
    XPOS=(RobotPositionX+round(r*cos(Radangle)));
    YPOS=RobotPositionY+round(r*sin(Radangle));
     if ( (XPOS>0) && (XPOS<1+size(ROBOMAP,2)) && (YPOS>0) &&(YPOS<1+size(ROBOMAP,1)) )

    if MAP(XPOS,YPOS)==0
     ROBOMAP(XPOS,YPOS)=1;
     if ROBOMAP(XPOS,YPOS)==-1
         ROBOMAP(XPOS,YPOS)=0;
     end 
 end
 
 if MAP(XPOS,YPOS)==1
        ROBOMAP(XPOS,YPOS)=2;
        plot([RobotPositionY YPOS],[257-RobotPositionX 257-XPOS],'color', [0.5 0.5 0.5])
                hold on
%        a=aaa;
        plot(YPOS,257-XPOS,'o','color','m')
        break
     end
end
end
end
plot(RobotPositionY,257-RobotPositionX,'*','color','r')
set(gca,'XTick',[0:32:256]);
set(gca,'YTick',[0:32:256]);
set(gca,'XtickLabels',[-6.8:1.6:6.8]);
set(gca,'YtickLabels',[-6.8:1.6:6.8]);

axis equal
figure(2)
h4=imagesc(flipud(ROBOMAP));
 colormap(flipud(gray));
hold on
plot(RobotPositionY,257-RobotPositionX,'*','color','r')

 
 
 
 %MAP=RefMap;
 clear
 load('Stuff')
 resolut=resolution
 ROBOMAP=MAP
 figure(3)
plot(RobotPositionY,257-RobotPositionX,'*','color','k','MarkerSize',10)
plot(RobotPositionX,257-RobotPositionY,'*','color','r','MarkerSize',10)

hold on
k=0;
%ROBOMAP(RobotPositionX,RobotPositionY)=1;
for Degangle=0:1:360
    Radangle=Degangle*pi/180;
for r=0:0.5:10/resolut;
    XPOS=(RobotPositionX+round(r*cos(Radangle)));
    YPOS=RobotPositionY+round(r*sin(Radangle));
     if ( (XPOS>0) && (XPOS<1+size(ROBOMAP,2)) && (YPOS>0) &&(YPOS<1+size(ROBOMAP,1)) )

    if MAP(XPOS,YPOS)==0
     ROBOMAP(XPOS,YPOS)=1;
     if ROBOMAP(XPOS,YPOS)==-1
         ROBOMAP(XPOS,YPOS)=0;
     end 
 end
 
 if MAP(XPOS,YPOS)==1
        ROBOMAP(XPOS,YPOS)=2;
        plot([RobotPositionY YPOS],[257-RobotPositionX 257-XPOS],'color',[0.5 0.5 0.5])
                hold on
        plot(YPOS,257-XPOS,'o','color','k')
        if k==0
            legend('Lidar Position','Emitted rays','Scanned Obstacle')
            k=1
            xlabel('X Position [m]')
ylabel('Y Position [m]')

        end
    
        break
     end
end
end
end
plot(RobotPositionY,257-RobotPositionX,'*','color','k','MarkerSize',10)
%set(gca,'XTick',[0:32:256]);
%set(gca,'YTick',[0:32:256]);
%set(gca,'XtickLabels',[-6.8:1.6:6.8]);
%set(gca,'YtickLabels',[6.8:-1.6:-6.8]);
xlim([70 180])
axis equal

figure(4)
h4=imagesc((ROBOMAP));
hold on
plot(RobotPositionY,RobotPositionX,'*','color','k','MarkerSize',10,'MarkerFaceColor','k')
hold on
plot(-1,-1,'square','color','k','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k')
plot(-1,-1,'square','color',[0.5 0.5 0.5],'MarkerSize',10,'MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5])

legend('Lidar Position','Scanned cell:Occupied','Scanned cell: Free')
xlabel('X-Position [m]')
ylabel('Y-Position [m]')

 colormap(flipud(gray));
set(gca,'XTick',[0:32:256]);
set(gca,'YTick',[0:32:256]);
set(gca,'XtickLabels',[-6.8:1.6:6.8]);
set(gca,'YtickLabels',[6.8:-1.6:-6.8]);
xlim([-3.6 2.8])
axis equal


 
end