%function []= DrawAStar(MAP,CLOSED,OPEN,Optimal_path,DummyMAP,CompValues)


close all
load HERE
load OpenNClosed
MAP=InfMAP

%  []  function DrawAStar(MAP,CLOSED,OPEN,Optimal_path,DummyMAP,CompValue,AStar)
close all
 colordata = gray;

 
InfMAP(MAP==1)=3;
closed1=[0.5 0.5 .5]
  colordata(3,:)=closed1;

 
InfMAP(ClosedMAT==1)=1;
closeds=[     0    0.7490    0.7490]

  colordata(1,:)=closeds;

InfMAP(MAP==2)=64;

Object=[0 0 0 ]
  colordata(end,:)=Object;

WHITE=[1 1 1]
InfMAP(MAP==0)=63
  colordata(end-1,:)=WHITE;
Explored=[0.5 0.5 0.5];


  colordata(end-2,:)=Explored;

InfMAP(OpenMAT==1)=62;
Open=[1 0.5 0.5]
Open=[1 1 0]

colordata(end-2,:)=Open;


h4=imagesc(InfMAP);
hold on

%  [0.5 0.5 0.5];
colormap(colordata);


plot(-1,-1,'square','color','k','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k')
%plot(-2,-2,'square','color',[0 0 0],'MarkerSize',10,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',WHITE)
plot(-1,-1,'square','color',Explored,'MarkerSize',10,'MarkerEdgeColor',Explored,'MarkerFaceColor',Explored)
plot(-3,-3,'square','color',closeds,'MarkerSize',10,'MarkerEdgeColor',closeds,'MarkerFaceColor',closeds)
%plot(-3,-3,'square','color',closed1  ,'MarkerSize',10,'MarkerEdgeColor',closed1 ,'MarkerFaceColor',closed1 )
plot(-3,-3,'square','color',Open  ,'MarkerSize',10,'MarkerEdgeColor',Open ,'MarkerFaceColor',Open )

plot(Optimal_path(end,2),Optimal_path(end,1),'*','color','r','markerSize',10)
plot(Optimal_path(1,2),Optimal_path(1,1),'o','color','b')
plot(Optimal_path(:,2),Optimal_path(:,1),'color',[0.8706    0.4902         0],'LineWidth',2)
legend('Occupied cell','Unexamined cells','Closed List','Open List ','Vessel position','Goal',' Chosen Path')

    axis equal
%xlim([27 238])
%ylim([75 180])

axis off

%colordata2(end,:) =[0.6350 0.0780 0.1840];
%colormap(colordata);
%corormap(
%colordata = colormap;
%colorbar
  %end
