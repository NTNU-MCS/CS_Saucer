%function OptimalPath=DrawAniPathAStar(StartX,StartY,MAP,GoalRegister,Connecting_Distance,WeightMap,DistWeight,SuperGoal)

clear
close all
load PathAstar
clear OptimalPath
SuperGoal=[20 5];
   % MAP(end+1,1:40)=zeros(1,40);
VideoName=['NewBatch11.avi']
MAP(30,15:25)=2;
MAP(26,10:15)=2;
MAP(26:30,15)=2;
MAP(30:35,20)=2;

DistWeight=0;
Connecting_Distance=4
DrawMap=MAP;
DrawMap(MAP==1)=3;
%DrawMap(MAP==2)=64;
WHITE=[1 1 1]
DrawMap(MAP==0)=63

 colordata = gray;

 
DrawMap(MAP==1)=3;
closed1=[0.5 0.5 .5]
  colordata(3,:)=closed1;

 
%InfMAP(ClosedMAT==1)=1;
closeds=[     0    0.7490    0.7490]

  colordata(1,:)=closeds;

DrawMap(MAP==2)=64;

Object=[0 0 0 ]
  colordata(end,:)=Object;

WHITE=[1 1 1]
DrawMap(MAP==0)=63
  colordata(end-1,:)=WHITE;
Explored=[0.5 0.5 0.5];


  colordata(end-2,:)=Explored;

%InfMAP(OpenMAT==1)=62;
Open=[1 0.5 0.5]
Open=[1 1 0]

colordata(end-2,:)=Open;


h4=imagesc([DrawMap;zeros(4,40)]);

hold on

axis equal
axis off
%xlim([25 235])
%ylim([70 180])

xlim([0 40])
ylim([0 44])

axis equal

plot(-1,-1,'square','color','k','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k')
%plot(-2,-2,'square','color',[0 0 0],'MarkerSize',10,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',WHITE)
plot(-1,-1,'square','color',Explored,'MarkerSize',10,'MarkerEdgeColor',Explored,'MarkerFaceColor',Explored)
plot(-3,-3,'square','color',closeds,'MarkerSize',10,'MarkerEdgeColor',closeds,'MarkerFaceColor',closeds)
%plot(-3,-3,'square','color',closed1  ,'MarkerSize',10,'MarkerEdgeColor',closed1 ,'MarkerFaceColor',closed1 )
plot(-3,-3,'square','color',Open  ,'MarkerSize',10,'MarkerEdgeColor',Open ,'MarkerFaceColor',Open )
plot(-3,-3,'square','color','g'  ,'MarkerSize',10,'MarkerEdgeColor','g' ,'MarkerFaceColor','g' )
plot(StartX,StartY,'o','color','k','markerSize',6,'MarkerFaceColor','r')
h7=plot(nan,nan,'o','color','k','markerSize',6,'MarkerFaceColor','b')
plot(SuperGoal(1),SuperGoal(2),'o','color','k','markerSize',6,'MarkerFaceColor','g')

h6=plot(nan,nan,'r','LineWidth',2);
h10=plot(nan,nan,':','color','r','LineWidth',3)

%plot(Optimal_path(end,2),Optimal_path(end,1),'*','color','r','markerSize',10)
%plot(Optimal_path(1,2),Optimal_path(1,1),'o','color','b')
%plot(Optimal_path(:,2),Optimal_path(:,1),'color',[0.8706    0.4902         0],'LineWidth',2)
%VideoName=['MostBasicCD1WOn.avi']

writerObj = VideoWriter(VideoName,'Uncompressed AVI');
%writerObj.Quality=100
open(writerObj);
pause(1)
%  [0.5 0.5 0.5];
  colordata(end-4,:)=[0 1 0];
  colordata(end-3,:)=[0 1 0];

colormap(colordata);
%a=AS
save colorStuff
%PathAstar -Generates a path in the occupancy grid
%to goal nodes according to the implemented A* algorithm

% Inputs:
% StartX,StartY = Position of the vessel/robot
% MAP=Occupancy grid that the vessel operates in
% GoalRegister=Matrix of goal nodes.
% Connecting_Distance= Connecting distance between individual nodes in the
% grid
% WeightMap= Grid containing the weigths of nodes
% DistWeight= Parameter deciding if nodes should be weigthed. (0=no,1=Weight first and last node in connection,2=Weigth all nodes in connection)
% SuperGoal= Has a value if user has defined an exploration goal outside of
% exlpored map. 

% Outputs:
%    OptimalPath= Matrix containing list of the calculated path
%
% SubFunctions: AstarFindCost(only used if distweight =2)

% Author: Einar Ueland1
% email: einarsu@stud.ntnu.no
% June 2016; Last revision: 01-June-2016



%FINDING ASTAR PATH IN AN OCCUPANCY GRID
%WeightMap=ones(256);
%nNeighboor=3;
% Preallocation of Matrices
[Height,Width]=size(MAP); %Height and width of matrix
GScore=zeros(Height,Width);           %Matrix keep  ing track of G-scores 
FScore=single(inf(Height,Width));     %Matrix keeping track of F-scores (only open list) 
Hn=single(zeros(Height,Width));       %Heuristic matrix
OpenMAT=int8(zeros(Height,Width));    %Matrix keeping of open grid cells
ClosedMAT=int8(zeros(Height,Width));  %Matrix keeping track of closed grid cells
ClosedMAT(MAP==2)=1;                  %Adding object-cells to closed matrix
ClosedMAT(MAP==0)=1;                  %Adding object-cells to closed matrix

ParentX=int16(zeros(Height,Width));   %Matrix keeping track of X position of parent
ParentY=int16(zeros(Height,Width));   %Matrix keeping track of Y position of parent
%colormap(flipud(gray))
%hold on
%plot(StartY,StartX);
%%% Setting up matrices representing neighboors to be investigated
NeighboorCheck=ones(2*Connecting_Distance+1);
Dummy=2*Connecting_Distance+2;
Mid=Connecting_Distance+1;
for i=1:Connecting_Distance-1
NeighboorCheck(i,i)=0;
NeighboorCheck(Dummy-i,i)=0;
NeighboorCheck(i,Dummy-i)=0;
NeighboorCheck(Dummy-i,Dummy-i)=0;
NeighboorCheck(Mid,i)=0;
NeighboorCheck(Mid,Dummy-i)=0;
NeighboorCheck(i,Mid)=0;
NeighboorCheck(Dummy-i,Mid)=0;
end
NeighboorCheck(Mid,Mid)=0;

[row, col]=find(NeighboorCheck==1);
Neighboors=[row col]-(Connecting_Distance+1);
N_Neighboors=size(col,1);
%%% End of setting up matrices representing neighboors to be investigated

%GoalRegister(128,128)=1
    DrawMap(GoalRegister==1)=60;
  colordata(end-4,:)=[0 1 0];

%%%%%%%%% Creating Heuristic-matrix based on distance to nearest  goal node
[row, col]=find(GoalRegister==1);
RegisteredGoals=[col row];
Nodesfound=size(RegisteredGoals,1);
%SuperGoal=[1 1];

if size(SuperGoal,1)>0
    Distance2SuperGoal=sqrt(sum(abs(RegisteredGoals-repmat(SuperGoal,size(RegisteredGoals,1),1)).^2,2));
WeigthDist2SuperGoal=1.7;
Distance2SuperGoal=Distance2SuperGoal*WeigthDist2SuperGoal;
minDistance2SuperGoal=min(Distance2SuperGoal);
FrontierWeigths=0*WeightMap;
for zzz=1:size(Distance2SuperGoal,1)
    FrontierWeigths(RegisteredGoals(zzz,2),RegisteredGoals(zzz,1))=WeigthDist2SuperGoal*(Distance2SuperGoal(zzz)-minDistance2SuperGoal);
end
end

for k=1:size(GoalRegister,1)
    for j=1:size(GoalRegister,2)
        if MAP(k,j)==1
            Mat=RegisteredGoals-(repmat([j k],(Nodesfound),1));
            if size(SuperGoal,1)>0
                Distance=(min(sqrt(sum(abs(Mat).^2,2))+Distance2SuperGoal));
            else 
                Distance=(min(sqrt(sum(abs(Mat).^2,2))));
            end
                Hn(k,j)=Distance;
        end
    end
end
%Hn=zeros(256,256)
%End of creating Heuristic-matrix. 
%Note: If Hn values is set to zero the method will reduce to the Dijkstras method.

%Initializign start node with FValue and opening first node.
FScore(StartY,StartX)=Hn(StartY,StartX);         
OpenMAT(StartY,StartX)=1;   




while 1==1 %Code will break when path found or when no path exist
    MINopenFSCORE=min(min(FScore));
    if MINopenFSCORE==inf;
    %Failuere!
    OptimalPath=[inf];
    RECONSTRUCTPATH=0;
     break
    end
    [CurrentY,CurrentX]=find(FScore==MINopenFSCORE);
    CurrentY=CurrentY(1);
    CurrentX=CurrentX(1);

    if GoalRegister(CurrentY,CurrentX)==1
    %GOAL!!
        RECONSTRUCTPATH=1;
        break
    end
    
  %Remobing node from OpenList to ClosedList  
    OpenMAT(CurrentY,CurrentX)=0;
    FScore(CurrentY,CurrentX)=inf;
    ClosedMAT(CurrentY,CurrentX)=1;
    for p=1:N_Neighboors
        i=Neighboors(p,1); %Y
        j=Neighboors(p,2); %X
        if CurrentY+i<1||CurrentY+i>Height||CurrentX+j<1||CurrentX+j>Width
            continue
        end
        Flag=1;
        if(ClosedMAT(CurrentY+i,CurrentX+j)==0) %Neiboor is open;
            if (abs(i)>1||abs(j)>1);   
                %Jumping over a grid cell, Need to check that the path does not hit an object
                JumpCells=2*max(abs(i),abs(j))-1;
                for K=1:JumpCells;
                    YPOS=round(K*i/JumpCells);
                    XPOS=round(K*j/JumpCells);
            
                    if (MAP(CurrentY+YPOS,CurrentX+XPOS)==2)
                        Flag=0;
                    end
                end
            end
            if Flag==1;           
                if DistWeight==1
                    tentative_gScore = GScore(CurrentY,CurrentX) + (WeightMap(CurrentY,CurrentX)+WeightMap(CurrentY+i,CurrentX+j))/2*sqrt(i^2+j^2);
                elseif DistWeight==0;
                    tentative_gScore = GScore(CurrentY,CurrentX) + sqrt(i^2+j^2);
                elseif DistWeight==2
                    tentative_gScore = GScore(CurrentY,CurrentX) +AstarFindCost(i,j,WeightMap,CurrentX,CurrentY);
                end
                if size(SuperGoal,1)>0
                tentative_gScore=tentative_gScore+FrontierWeigths(CurrentY+i,CurrentX+j);
                %% 
                end
                    if OpenMAT(CurrentY+i,CurrentX+j)==0
                    OpenMAT(CurrentY+i,CurrentX+j)=1;                    
                elseif tentative_gScore >= GScore(CurrentY+i,CurrentX+j);
                    continue
                end
                ParentX(CurrentY+i,CurrentX+j)=CurrentX;
                ParentY(CurrentY+i,CurrentX+j)=CurrentY;
                GScore(CurrentY+i,CurrentX+j)=tentative_gScore;
                FScore(CurrentY+i,CurrentX+j)= tentative_gScore+Hn(CurrentY+i,CurrentX+j);
            end
        end
    end
    DrawMap(MAP==1)=3;

    DrawMap(ClosedMAT==1)=1;
    DrawMap(MAP==2)=64;

    DrawMap(MAP==0)=63;

    DrawMap(OpenMAT==1)=62;
    DrawMap(GoalRegister==1)=60;
%   pause(0.1)
    set(h4,'CData',[DrawMap;63*ones(4,40)]);
    
    set(gca,'nextplot','replacechildren');
set(gcf,'Renderer','zbuffer');
frame = getframe;
writeVideo(writerObj,frame);

    
end
hold on
k=2;
set(h7,'XData',CurrentX,'YData',CurrentY)
if RECONSTRUCTPATH
    OptimalPath(1,:)=[CurrentY CurrentX];

    while RECONSTRUCTPATH
set(h6,'YData',OptimalPath(:,1),'XData',OptimalPath(:,2))

for i=1:2
    set(gca,'nextplot','replacechildren');
set(gcf,'Renderer','zbuffer');
frame = getframe;
writeVideo(writerObj,frame);
end

        if (((CurrentX== StartX)) &&(CurrentY==StartY))
            break
        end

        CurrentXDummy=ParentX(CurrentY,CurrentX);
        CurrentY=ParentY(CurrentY,CurrentX);
        CurrentX=CurrentXDummy;
        OptimalPath(k,:)=[CurrentY CurrentX];
        k=k+1;
    end
end
XSTART=OptimalPath(1,1);
YSTART=OptimalPath(1,2);
dx=(SuperGoal(2)-XSTART)/30;
dy=(SuperGoal(1)-YSTART)/30;
for i=1:30
        legend('Occupied cell','Explored cells','Closed List','Open List ','Frontier Cell','Robot position','Goal',' Exploration Goal','Chosen Path')

    set(h10,'YData',[XSTART XSTART+dx*i],'XData',[YSTART YSTART+(dy*i)])
    set(gca,'nextplot','replacechildren');
set(gcf,'Renderer','zbuffer');
frame = getframe;
writeVideo(writerObj,frame);
end
if size(SuperGoal,1)>1
legend('Occupied cell','Explored cells','Closed List','Open List ','Frontier Cell','Robot position','Goal','Exploration Goal',' Chosen Path')
else
    legend('Occupied cell','Explored cells','Closed List','Open List ','Frontier Cell','Robot position','Goal',' Exploration Goal','Chosen Path')
end
pause(2)

for i=1:30
    
        set(gca,'nextplot','replacechildren');
set(gcf,'Renderer','zbuffer');
frame = getframe;
writeVideo(writerObj,frame);
end

close(writerObj)

save('OpenNClosed')


      
    

