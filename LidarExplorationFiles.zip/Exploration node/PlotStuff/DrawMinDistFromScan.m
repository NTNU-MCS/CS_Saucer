  Mindist=linspace(0,6,100)
for i=1:length(Mindist)
    mindist=(Mindist(i))
if mindist<1
    EtaSet(i)=mindist-0.2;
else 
EtaSet(i)=2*mindist-1.2;
end
EtaSet(i)=min([EtaSet(i) 3])
EtaSet(i)=max([EtaSet(i) 0.1]);
end     
plot(Mindist,EtaSet,'k','LineWidth',2)
xlabel('Minimal distance from scan [m]')
ylabel('EtaSet distance [m]')
