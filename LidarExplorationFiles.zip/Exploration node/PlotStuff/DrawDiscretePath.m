%plottravelDist
close all
clear
load HERE
load End Optimal_path
 load PreMapper
 load HERE
%imagesc(TravelDist)
TravelDist(TravelDist==51)=2
TravelDist(InfMAP==2)=max(max(TravelDist))+2

TravelDist(TravelDist==0)=max(max(TravelDist))
imagesc(TravelDist)

%colormap(flipud(gray));
 colordata = colormap;
colormap(colordata);
colordata(end,:) =[0 0 0];
colordata(1,:) = [1 1 1];
imagesc(TravelDist)

hold on
colormap(colordata);
colordata = colormap;
c=colorbar
K=size(Optimal_path,1);

c.Label.String = 'Weight of node'; 
close all
h4=imagesc(InfMAP);
    colormap(flipud(gray));
RobotPositionX=80
RobotPositionYMap=110
set(h4,'CData',double(InfMAP)./2)
hold on

%h6=plot(nan,nan,'o','color','r','LineWidth',2);
h7= plot(nan,nan,'color','k','LineWidth',2);
    h8= plot(nan,nan,'o','color','b','MarkerFaceColor','b');
    set(h8,'XData',[Optimal_path(1:K,2)],'YData',[Optimal_path(1:K,1)])

    h1=plot(nan,nan,'*','color','r','MarkerSize',10);
set(h1,'XData',RobotPositionX,'YData',RobotPositionYMap)

set(h7,'XData',[Optimal_path(1:K,2)],'YData',[Optimal_path(1:K,1)])
%set(h6,'XData',Optimal_path(1,2),'YData',Optimal_path(1,1))
axis off 
axis equal
xlim([65 100])
ylim([80 150])




axis off 
xlim([65 100])
axis equal

ylim([80 130])
xlim([65 100])

legend('Path','Discrete points on path','Vessel position')

a=asl
close all


eta=[80 110];
Values=Optimal_path;

EtaSetDistance=1
%DiscretizedPath
DiscretizedStep=0.01/0.2;
counter=1;
DiscretizedPath=zeros(8000,2);
for k=2:size(Optimal_path,1)-1
    DistanceTraveled=norm([Values(k,1)-Values(k-1,1) Values(k,2)-Values(k-1,2)]) ;
    DistanceTraveledX=Values(k,1)-Values(k-1,1);
    DistanceTraveledY=Values(k,2)-Values(k-1,2);
    Niterations=floor(DistanceTraveled/DiscretizedStep);
for z=1:Niterations
    DiscretizedPath(counter,1)=Values(k-1,1)+z*DistanceTraveledX/Niterations;
    DiscretizedPath(counter,2)=Values(k-1,2)+z*DistanceTraveledY/Niterations;
counter=counter+1;
end
end
DiscretizedEnds=min([find(DiscretizedPath==0) ;size(DiscretizedPath,1)]);
DiscretizedPath=DiscretizedPath(1:DiscretizedEnds-1,1:2);

%%a=asl
eta=eta(2:-1:1)'

%Discretizing PathVector


NearestPointPos=4;
AvstandSaved=1000;
%for i=1:64
%AvstandDummy=(eta(1)-Values(i,1))^2+(eta(2)-Values(i,2))^2;
% if AvstandDummy<AvstandSaved
%     AvstandDummy=AvstandSaved;
% NearestPointPos=i;
% end
%end

    [Avstand NearestPointPos]=min((sum((abs(DiscretizedPath-repmat(eta',size(DiscretizedPath,1),1))).^2')));
if (NearestPointPos-3)>1
    SetPoint=NearestPointPos-3;

else SetPoint=1;
    
end
NIter=round(EtaSetDistance*5/DiscretizedStep);
    h4=imagesc(InfMAP);
    colormap(flipud(gray));
hold on
plot(DiscretizedPath(:,2),DiscretizedPath(:,1),'k')
plot(RobotPositionX,RobotPositionYMap,'*','color','r','MarkerSize',10)
SetPoint=max([1 NearestPointPos-NIter]);
y(1)=DiscretizedPath(SetPoint,2);
y(2)=DiscretizedPath(SetPoint,1);
plot(y(1),y(2),'o','color','m','MarkerFaceColor','m')
yStart(1)=DiscretizedPath(NearestPointPos,2);
yStart(2)=DiscretizedPath(NearestPointPos,1);
plot(yStart(1),yStart(2),'o','color','r','MarkerFaceColor','y')
plot(DiscretizedPath(:,2),DiscretizedPath(:,1),'o','color','b','MarkerFaceColor','b')
legend('Path','Vessel Position','Chosen setpoint','Closest point on path','Discretized path')
plot(DiscretizedPath(:,2),DiscretizedPath(:,1),'k')

plot(yStart(1),yStart(2),'o','color','r','MarkerFaceColor','y')
plot(y(1),y(2),'o','color','m','MarkerFaceColor','m')


axis off 
xlim([65 100])
axis equal

ylim([80 130])
xlim([65 100])

%etaset = u;11
%HEADING:
%end



