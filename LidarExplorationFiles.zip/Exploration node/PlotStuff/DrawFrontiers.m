    function []=DrawFrontiers(InfMAP,CompValues)

h4=imagesc(InfMAP);
 colormap(flipud(gray));
hold on
plot(-1,-1,'square','color','k','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k')
plot(-1,-1,'square','color',[0.5 0.5 0.5],'MarkerSize',10,'MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5])
plot(-2,-2,'square','color',[0.8 0.8 0.8],'MarkerSize',10,'MarkerEdgeColor',[0.8 0.8 0.8],'MarkerFaceColor',[0.8 0.8 0.8])
plot(-3,-3,'square','color',[0.3 0.3 0.3],'MarkerSize',10,'MarkerEdgeColor',[0.3 0.3 0.3],'MarkerFaceColor',[0.3 0.3 0.3])

legend('Detected Frontier','Scanned cell:Occupied','Scanned cell: Free')
xlabel('X-Position [m]')
ylabel('Y-Position [m]')

 

InfMAP(InfMAP==2)=6;
for i=1:size(CompValues,1)
InfMAP(CompValues(i,1),CompValues(i,2))=12;
end
set(h4,'CData',double(InfMAP)./2)



end
