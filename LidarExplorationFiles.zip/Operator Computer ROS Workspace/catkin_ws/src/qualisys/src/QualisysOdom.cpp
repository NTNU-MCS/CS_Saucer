#include <qualisys/QualisysOdom.h>

#include <Eigen/Geometry>
#include <nav_msgs/Odometry.h>

namespace qualisys
{
QualisysOdom::QualisysOdom(ros::NodeHandle &n):
  nh(n) {
  return;
}

bool QualisysOdom::init() {
  double max_accel;
  nh.param("max_accel", max_accel, 5.0);
  //nh.param("publish_tf", publish_tf_, false);
  //if(publish_tf_ && !nh.getParam("child_frame_id", child_frame_id_)) {
  //  throw std::runtime_error("qualisys_odom: child_frame_id required for publishing tf");
  //  return false;
  //}

  // There should only be one vicon_fps, so we read from nh
  double dt, qualisys_fps;
  nh.param("qualisys_fps", qualisys_fps, 100.0);
  ROS_ASSERT(qualisys_fps > 0.0);
  dt = 1 / qualisys_fps;

  // Initialize KalmanFilter
  KalmanFilter::State_t proc_noise_diag;
  proc_noise_diag(0) = 0.5 * max_accel * dt * dt;
  proc_noise_diag(1) = 0.5 * max_accel * dt * dt;
  proc_noise_diag(2) = 0.5 * max_accel * dt * dt;
  proc_noise_diag(3) = max_accel * dt;
  proc_noise_diag(4) = max_accel * dt;
  proc_noise_diag(5) = max_accel * dt;
  proc_noise_diag = proc_noise_diag.array().square();
  KalmanFilter::Measurement_t meas_noise_diag;
  meas_noise_diag(0) = 1e-4;
  meas_noise_diag(1) = 1e-4;
  meas_noise_diag(2) = 1e-4;
  meas_noise_diag = meas_noise_diag.array().square();
  kf_.initialize(KalmanFilter::State_t::Zero(),
                 0.01 * KalmanFilter::ProcessCov_t::Identity(),
                 proc_noise_diag.asDiagonal(), meas_noise_diag.asDiagonal());

  // Initialize publisher and subscriber
  odom_pub_ = nh.advertise<nav_msgs::Odometry>("odom", 10);
  qualisys_sub_ = nh.subscribe("qualisys_subject", 10, &QualisysOdom::QualisysCallback,
                            this, ros::TransportHints().tcpNoDelay());
  return true;
}

void QualisysOdom::QualisysCallback(const qualisys::Subject::ConstPtr &msg)
{
  static ros::Time t_last_proc = msg->header.stamp;
  double dt = (msg->header.stamp - t_last_proc).toSec();
  t_last_proc = msg->header.stamp;

  // Kalman filter for getting translational velocity from position measurements
  kf_.processUpdate(dt);
  const KalmanFilter::Measurement_t meas(msg->position.x, msg->position.y,
                                         msg->position.z);
  if(!msg->occluded)
  {
    static ros::Time t_last_meas = msg->header.stamp;
    double meas_dt = (msg->header.stamp - t_last_meas).toSec();
    t_last_meas = msg->header.stamp;
    kf_.measurementUpdate(meas, meas_dt);
  }

  const KalmanFilter::State_t state = kf_.getState();
  const KalmanFilter::ProcessCov_t proc_noise = kf_.getProcessNoise();

  nav_msgs::Odometry odom_msg;
  odom_msg.header = msg->header;
  odom_msg.child_frame_id = msg->name;
  odom_msg.pose.pose.position.x = state(0);
  odom_msg.pose.pose.position.y = state(1);
  odom_msg.pose.pose.position.z = state(2);
  odom_msg.twist.twist.linear.x = state(3);
  odom_msg.twist.twist.linear.y = state(4);
  odom_msg.twist.twist.linear.z = state(5);
  for(int i = 0; i < 3; i++)
  {
    for(int j = 0; j < 3; j++)
    {
      odom_msg.pose.covariance[6 * i + j] = proc_noise(i, j);
      odom_msg.twist.covariance[6 * i + j] = proc_noise(3 + i, 3 + j);
    }
  }

  odom_msg.pose.pose.orientation = msg->orientation;

  // Single step differentitation for angular velocity
  static Eigen::Matrix3d R_prev(Eigen::Matrix3d::Identity());
  Eigen::Matrix3d R(Eigen::Quaterniond(msg->orientation.w, msg->orientation.x,
                                       msg->orientation.y, msg->orientation.z));
  if(dt > 1e-6)
  {
    const Eigen::Matrix3d R_dot = (R - R_prev) / dt;
    const Eigen::Matrix3d w_hat = R_dot * R.transpose();

    odom_msg.twist.twist.angular.x = w_hat(2, 1);
    odom_msg.twist.twist.angular.y = w_hat(0, 2);
    odom_msg.twist.twist.angular.z = w_hat(1, 0);
  }
  R_prev = R;

  odom_pub_.publish(odom_msg);
  //if(publish_tf_)
  //{
  //  PublishTransform(odom_msg.pose.pose, odom_msg.header,
  //                   odom_msg.child_frame_id);
  //}
}

//void QualisysOdom::PublishTransform(const geometry_msgs::Pose &pose,
//                                 const std_msgs::Header &header,
//                                 const std::string &child_frame_id)
//{
//  // Publish tf
//  geometry_msgs::Vector3 translation;
//  translation.x = pose.position.x;
//  translation.y = pose.position.y;
//  translation.z = pose.position.z;
//
//  geometry_msgs::TransformStamped transform_stamped;
//  transform_stamped.header = header;
//  transform_stamped.child_frame_id = child_frame_id;
//  transform_stamped.transform.translation = translation;
//  transform_stamped.transform.rotation = pose.orientation;
//
//  tf_broadcaster_.sendTransform(transform_stamped);
//}

} // namespace qualisys
