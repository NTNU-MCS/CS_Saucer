Collection of Launch files. 
Some of these launch files are also in the respective workspaces folders for the operator computer and the RP2.


mapping_defaultRes02256.launch is the Hector_Mapping launch file for gridsize (256x256)
Res0256.launch is the Hector_SLAM_Launch file for gridsize (256x256)

Simulation.launch is the launch file for simulations. 