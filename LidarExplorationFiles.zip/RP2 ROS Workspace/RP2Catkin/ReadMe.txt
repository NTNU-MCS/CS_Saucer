Used 7zip to compress this folder. (Got an error with Windows archive manager)

Should be easy to unpack. For isntance with the mentioned 7zip
http://www.7-zip.org/ (this is one of the most popular compression tools)
