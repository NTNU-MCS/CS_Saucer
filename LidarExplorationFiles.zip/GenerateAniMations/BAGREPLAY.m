
%Generates animation of Bagfiles from experiments 
close all
clear

%Dummy variables and initialization
N=25; 
X=linspace(0,2*pi,N);
EtaReg=[]
z=1;
a=1;


BAG=rosbag('BagSample.bag')

initTime=BAG.StartTime
%opening writer object
writerObj = VideoWriter('BAGGREPLAYGAP.avi','Uncompressed AVI');
open(writerObj);

%Iterating and producing animation
kNum=floor(BAG.NumMessages/1000)
for zzz=1:kNum
  msgs=readMessages(BAG,(zzz-1)*1000+1:zzz*1000)

  if zzz==1
for i=1:1000
     Topic=BAG.MessageList.Topic(i);
    if Topic==   '/map' 
u=msgs{i,1}.Data;
resolution=msgs{i,1}.Info.Resolution;
K=length(u)^0.5;
MAP=zeros(K,K);
for i=1:K;
    MAP(i,1:K)=u((i-1)*K+1:i*K);
    break
end

%MAP=int8(MAP);
MAP(MAP>50)=2;
MAP(MAP==0)=1;
MAP(MAP<0)=0;

MAP(1,1)=2;

[Height Width]=size(MAP);
MID=Height*resolution/2;


%
 figure(1)
h4=imagesc(MAP);
 colormap(flipud(gray));
hold on
h1=plot(nan,nan,'*','color','r');
h2=plot(nan,nan,'--');
h3=plot(nan,nan,'o','color','b');
h5=plot(nan,nan,'y')
h6=plot(nan,nan,'o','color','r');
h7= plot(nan,nan,'k');
h8=plot(nan,nan,'o','color','k')
h9=plot(nan,nan,'o','color','r')
h10=plot(nan,nan,':','color','b')
h11=plot(nan,nan,'o','color','k')
h12=plot(nan,nan,'o','color','r')
%hhh12=plot(nan,nan,'y')

MAP(1,1)=0;


%hh1=plot([Circ1(1,:)]+eta(1),[Circ1(1,:)]+eta(2),'c','color','k');
%hh2=plot(Thrust1(1,:),Thrust1(2,:),'c','color','k');
hh1=plot(nan,nan,'c','color','r');
hh2=plot(nan,nan,'c','color','k');
hh3=plot(nan,nan,'c','color','k');
hh4=plot(nan,nan,'c','color','k');
hh5=plot(nan,nan,'c','color','k');
hh6=plot(nan,nan,'c','color','k');
hh7=plot(nan,nan,'c','color','k');
hh8=plot(nan,nan,'c','color','g','LineStyle','-','LineWidth',1);
hh9=plot(nan,nan,'c','color','r','LineStyle',':','LineWidth',1);

break





end
end
  end


for i=1:1000
  ii=(zzz-1)*1000+i;
    Time=BAG.MessageList.Time(ii)-initTime;
     Topic=BAG.MessageList.Topic(ii);
    if Topic=='/Eta'
%       msgs{i,1}.Topics
      Eta= [msgs{i,1}.X -msgs{i,1}.Y msgs{i,1}.Z];

    RobotPositionX=((Eta(1)+MID)/resolution);
    RobotPositionYMap=Height-((-Eta(2)+ MID)/resolution);
    if Eta(1)~=0 
    EtaReg(z,1:2)=[RobotPositionX RobotPositionYMap];
z=z+1;
    set(h10,'XData',EtaReg(:,1),'YData',EtaReg(:,2));

    end
    
        set(h1,'XData',RobotPositionX,'YData',RobotPositionYMap);

%pause(0.02)
%    set('h1','XData',,nan,'*','color','r')
    elseif Topic==   '/map' 
u=msgs{i,1}.Data;
K=length(u)^0.5;
MAP=zeros(K,K);
for i=1:K;
    MAP(i,1:K)=u((i-1)*K+1:i*K);
end

%MAP=int8(MAP);
MAP(MAP>50)=2;
MAP(MAP==0)=1;
MAP(MAP<0)=0;
%pause(2)
pause(0.1)
set(h4,'CData',MAP)
%MAP(1,1)=2;


%set(h4,'CData',MAP)
    elseif Topic=='/EtaSet' 
      EtaSet= [msgs{i,1}.X -msgs{i,1}.Y msgs{i,1}.Z];
    RobotPositionX=((EtaSet(1)+MID)/resolution);
    RobotPositionYMap=Height-((-EtaSet(2)+ MID)/resolution);
    set(h3,'XData',RobotPositionX,'YData',RobotPositionYMap);

        elseif Topic=='/GAPS' 
            msgs{i,1}
            msgs{i,1}.Data
            GAPLIST=msgs{i,1}.Data;
            L=size(GAPLIST,1)/2
            GAPS=[GAPLIST(1:L) GAPLIST(L+1:end)]
            [a]=ismember(GAPS, [100 100],'rows');
             a=find(a==1)
             min(a)
             set(h11,'XData',GAPS(:,2),'YDATA',GAPS(:,1))
        elseif Topic=='/UNFGAPS' 
            UNFLAGLIST=msgs{i,1}.Data;
            L=size(UNFLAGLIST,1)/2
            UNFLAGS=[UNFLAGLIST(1:L) UNFLAGLIST(L+1:end)]
            [a]=ismember(UNFLAGS, [100 100],'rows');
             a=find(a==1)
             min(a)
             set(h12,'XData',UNFLAGS(:,2),'YDATA',UNFLAGS(:,1))


    
    elseif Topic=='/EtaSetList'
    uEtaList=msgs{i,1}.Data;
        save TESTPRE uEtaList

    Z=length(uEtaList);
    find(uEtaList==1000);
    u1=-uEtaList(1:Z/2);
    u2=uEtaList(Z/2+1:end);
    [LAST]=find(u2==1000)
    
    Last=(find(u2==1000));
    if size(LAST,2)<1
    Last=length(u2);
    else
            Last=Last(1)-1
    end
    RobotPositionX=((u2(1:Last)+MID)./resolution);
    RobotPositionYMap=Height-((-u1(1:Last)+ MID)./resolution);
set(h5,'XData',RobotPositionX,'YData',RobotPositionYMap)
    u1=(u1+MID)/resolution;
    u2=(u2+MID)/resolution;
    %set(hhh12,'XData',u2','YData',u1)
    save('TEEST')
    elseif Topic=='/U'&& exist('Eta')
        %resolution=0.05;
    F_x=0; F_y=0;
 %Find F_x And F_y from tr
        U= [msgs{i,1}.X msgs{i,1}.Y msgs{i,1}.Z];
              init_a1=pi;
init_a2=60*pi/180;
init_a3=-60*pi/180;
alpha1=0;
alpha2=0;
alpha3=0;
U1=U(1);
U2=U(2);
U3=U(3);
XPos=Eta(1);
YPos=Eta(2);
psi=Eta(3);
R=[cos(psi) -sin(psi);sin(psi) cos(psi)];


R2=4*0.548/2;
R1=4*0.138;
RThrust=4*0.05;

%Position of Thrusters in bodyframe
PThrust1=4*[0.138 0];
PThrust2=[-R1*sin(30*(pi/180)) R1*cos(30*(pi/180))];
PThrust3=[-R1*sin(30*(pi/180)) -R1*cos(30*(pi/180))];

%Thruster Circles body frame
Thrust1=[RThrust*cos(X)+PThrust1(1);RThrust*sin(X)+PThrust1(2)];
Thrust2=[RThrust*cos(X)+PThrust2(1);RThrust*sin(X)+PThrust2(2)];
Thrust3=[RThrust*cos(X)+PThrust3(1);RThrust*sin(X)+PThrust3(2)];

%Thruster circles XY frame
Thrust1=R*Thrust1+[repmat(XPos,1,size(Thrust1,2));repmat(YPos,1,size(Thrust1,2))];
Thrust2=R*Thrust2+[repmat(XPos,1,size(Thrust2,2));repmat(YPos,1,size(Thrust2,2))];
Thrust3=R*Thrust3+[repmat(XPos,1,size(Thrust3,2));repmat(YPos,1,size(Thrust3,2))];

%Thrusts bodyframe
Tau1=[PThrust1;[PThrust1+[U1*sin(init_a1+alpha1) U1*cos(init_a1+alpha1)]]]';
Tau2=[PThrust2;[PThrust2+[U2*sin(init_a2+alpha2) U2*cos(init_a2+alpha2)]]]';
Tau3=[PThrust3;[PThrust3+[U3*sin(init_a3+alpha3) U3*cos(init_a3+alpha3)]]]';

%Thrust in XY frame
Tau1=R*Tau1+[XPos XPos;YPos YPos];
Tau2=R*Tau2+[XPos XPos;YPos YPos];
Tau3=R*Tau3+[XPos XPos;YPos YPos];
%%%%%%%%%%%%%%%%%%%%

%Defining global force vector
ForceVec=[0 F_x;0 F_y];
FGlob=R*ForceVec+[XPos XPos;YPos YPos];

%Outer circle (Hull of vessel)
Circ1=[R2*cos(X);R2*sin(X)];

    RobotPositionX=((Eta(1)+MID)/resolution);
    RobotPositionYMap=Height-((-Eta(2)+ MID)/resolution);

set(hh1,'Xdata',RobotPositionX+[Circ1(1,:)/resolution],'YData',RobotPositionYMap+[Circ1(2,:)/resolution]);

     set(hh2, 'XData',Height-(-Thrust1(1,:)+MID)/resolution, 'YData',(Thrust1(2,:)+MID)/resolution);

     set(hh3, 'XData',Height-(-Thrust2(1,:)+MID)/resolution, 'YData',(Thrust2(2,:)+MID)/resolution);
         set(hh4, 'XData',Height-(-Thrust3(1,:)+MID)/resolution, 'YData',(Thrust3(2,:)+MID)/resolution);
     set(hh5, 'XData',Height-(-Tau1(1,:)+MID)/resolution, 'YData',(Tau1(2,:)+MID)/resolution);
     set(hh6, 'XData',Height-(-Tau2(1,:)+MID)/resolution, 'YData',(Tau2(2,:)+MID)/resolution);
     set(hh7, 'XData',Height-(-Tau3(1,:)+MID)/resolution, 'YData',(Tau3(2,:)+MID)/resolution);

     %set(hh5, 'YData', Tau1(1,:), 'XData', Tau1(2,:));
     %set(hh6, 'YData', Tau2(1,:), 'XData', Tau2(2,:));
     %set(hh7, 'YData', Tau3(1,:), 'XData', Tau3(2,:));
    set(hh8,'YData',FGlob(1,:),'XData', FGlob(2,:));
%    set(hh9,'YData',PositionMatrix(1,:),'XData',PositionMatrix(2,:));




              %a=asl
     elseif Topic==   '/scan' 
Ranges=msgs{i,1}.Ranges;         
for i=1:length(Ranges)
             XPos(i)=0;
             YPos(i)=0;
end
   
    end
    if Time<1
                Time=num2str(round(Time*100)/100,3)
    elseif Time<10
        Time=[num2str(round(Time*10)/10,3)];
           title(['Time elapsed:   ' [num2str(Time,3)] 's']);
    elseif Time<10; 
                Time=[num2str(Time,3)];
   title(['Time elapsed:   ' [num2str(Time,3)] 's']);
   else
          title(['Time elapsed:   ' [num2str(Time,3)] 's']);
    end
    
    txt1 = ['Elapsed time: ' [num2str(Time,3)]];
if ~exist('T1')
    T1=text(Height*0.5,Height*0.05,txt1)
else 
    set(T1,'String',txt1)
end
    if mod(i,10)==0
    pause(0.2)
    
    set(gca,'nextplot','replacechildren');
set(gcf,'Renderer','zbuffer');
frame = getframe;
writeVideo(writerObj,frame);
    end
end
    end
close(writerObj)